MedMNIST v2 replication + DermaMNIST equity audit — figure bundle
================================================================

Source repo : AIscend-Research/medmnist-imaging-repro
Generated   : from report/ and results/ after the 31-run replication matrix
              (40 runs total incl. extension variants; 18.9 GPU-hours, Tesla T4)
Formats     : PNG = 300 dpi raster; PDF = vector (use the PDF in LaTeX)


imaging/ — figures showing the actual dermatoscopic images
----------------------------------------------------------
01_dermamnist_sample_montage.png
    8 training samples per class, all 7 DermaMNIST lesion types, at native
    28x28. Shows what the model actually sees, and how little signal
    separates the rare classes at this resolution.

02_misclassified_rare_class_gallery.png / .pdf
    Rare-class test cases the baseline ResNet-18 got wrong, captioned with
    true label, predicted label, and softmax confidence. The headline case:
    a dermatofibroma predicted as melanocytic nevi at confidence 1.00.
    Every error shown collapses a rare class into the 67%-majority nevi
    class or into melanoma — the failure mode is directional, not random.
    NOTE: the subplot spacing in this render is too wide; regenerate via
    src.extensions.plot_misclassified_gallery before using in the paper.


replication/ — main paper figures (ours vs MedMNIST v2 Table 3)
---------------------------------------------------------------
fig1_reproduction        ours-vs-paper AUC/ACC scatter across the twelve 2D
                         datasets at ResNet-18 @28, plus DermaMNIST bars
fig2_training_curves     validation AUC and training loss with LR-decay
                         markers at epochs 50 and 75
fig3_seed_variance       test-AUC spread across seeds {0,1,2}
fig4_delta_heatmap       signed (ours - paper) deltas per dataset/metric
fig5_compute_footprint   wall-clock and GPU cost per configuration


extension/ — DermaMNIST equity audit
-------------------------------------
ext_class_distribution   training-set class imbalance (nevi ~67%)
ext_freq_perf            training count vs per-class recall.
                         Pearson r = 0.805 (count vs recall)
                         Pearson r = -0.282 (count vs AUC)  <- the key result:
                         ROC-AUC does not track frequency, recall does, so the
                         benchmark's headline metric hides the equity failure
ext_per_class_perf       per-class AUC and F1, ordered rare -> common, +/-std
                         over 3 seeds
ext_pr_curves            per-class precision-recall (honest under imbalance)
ext_mitigation           baseline vs weighted sampler vs weighted loss
ext_calibration          reliability diagram + per-class confidence.
                         ECE: overall 0.062, common 0.053, rare 0.208
ext_efficiency           0.5x-width variant: params, MB, latency vs accuracy
ext_robustness           AUC under Gaussian noise / JPEG / brightness shift
confusion_baseline       baseline confusion matrix
roc_baseline             per-class ROC curves
bias_perclass_f1         per-class F1 before/after mitigation


prior_runs/ — earlier evidence, retained for provenance
--------------------------------------------------------
Seed-0 equity pass run before the src/ package existed (own code), plus the
reproduction arm executed with the authors' own train_and_eval_pytorch.py
(personA = ResNet-18 @224, personB = ResNet-50 @224). Both reproduce inside
tolerance. These are NOT the replication arm; see notebooks/README.md for the
full provenance split.


Headline numbers
----------------
Replication : 9 of 13 configurations inside |dAUC| <= 0.02, |dACC| <= 0.03.
              DermaMNIST reproduces to 0.003 AUC. PathMNIST exceeds the paper.
              Out of tolerance: breastmnist (n=546, high seed variance),
              octmnist ACC, pneumoniamnist ACC, retinamnist AUC. Three of the
              four are accuracy-only misses with healthy AUC.

Equity      : dermatofibroma recall 0.087 (23 test cases) while its per-class
              AUC reads 0.917. Weighted sampler lifts min-class F1
              0.160 -> 0.214 and accuracy 0.730 -> 0.735 for 1.7 AUC points.
              Weighted loss lifts dermatofibroma recall 0.087 -> 0.435 but
              drops accuracy to 0.633.

Efficiency  : 0.5x width = 11.17M -> 2.80M params, 42.7 -> 10.7 MB, latency
              unchanged (2.019 -> 2.039 ms/img; memory-bound at 28x28).
              Dermatofibroma F1 goes 0.16 -> 0.00: compression erases the
              rarest class entirely.
